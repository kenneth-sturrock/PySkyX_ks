#!/usr/bin/env python3

#
# Ken Sturrock
# January 2, 2024
#

from library.PySkyX_ks import *

import sys
import glob

argvLen = len(sys.argv)

if (argvLen == 1):
    timeStamp("ERROR. Please specify image names to process.")
    sys.exit()
 
if sys.platform == "win32":
    fileList = []
    
    for fileName in glob.glob(sys.argv[1]):
        fileList.append(fileName)
else:
    fileList = sys.argv
    fileList.pop(0)

fileNum = (len(fileList))

counter = 0

print("----------")
timeStamp("Fixing SITELONG keyword sign to reflect modern conventions.")

while (counter < fileNum):

    print("--------------------------------------------------------------------------------")
    print("Processing image: " + str(counter + 1) + " of " + str(fileNum))
    print("--------------------------------------------------------------------------------")

    imgPath = fileList[counter]

    newPathName = flipPath(imgPath)

    TSXSend("ccdsoftCameraImage.DetachOnClose = 0")
    TSXSend('ImageLink.pathToFITS = "' + newPathName + '"')
    TSXSend('ccdsoftCameraImage.Path = "' + newPathName + '"')
    TSXSend("ccdsoftCameraImage.Open()")

    obsgeoValue = TSXSend('ccdsoftCameraImage.FITSKeyword("OBSGEO-L")')
    sitelongValue = TSXSend('ccdsoftCameraImage.FITSKeyword("SITELONG")')


    if (float(obsgeoValue) >= 0):
        writeNote("Site location is east longitude.")
        newSitelongValue = "+" + sitelongValue[1:]

    else:
        writeNote("Site location is west longitude.")
        newSitelongValue = "-" + sitelongValue[1:]
    
    writeSpaced("(Before) SITELONG = " + sitelongValue)
    writeSpaced("(After)  SITELONG = " + newSitelongValue)



    TSXSend('ccdsoftCameraImage.setFITSKeyword("SITELONG", "' + newSitelongValue +'")')

    TSXSend("ccdsoftCameraImage.Save()")

    TSXSend("ccdsoftCameraImage.Close()")

    counter = counter + 1

print("----------")
timeStamp("Finished.")

