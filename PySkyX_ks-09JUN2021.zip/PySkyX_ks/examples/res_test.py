#!/usr/bin/env python3
#

from library.PySkyX_ks import *

import time
import socket
import sys
import os
import random
import math
import pathlib
import glob
import statistics

def resurrectTest():
#
# This will attempt to restart SkyX and reconnect devices. 
#
# Only sort-of works on Macintosh and during an imaging run, so far...
#
    # Is this a Macintosh?
    if 1 == 1:
        currentTS = time.time()
        newestImageDif = 3600 # This is a throw-away upper boundry
        newestImageName = ""

        imgPath = TSXSend('ccdsoftCamera.PropStr("m_csAutoSavePath")')

        imgPath = os.path.abspath(imgPath)
        imgPath = pathlib.Path(imgPath)
        if sys.platform == "win32":
            imgPath = str(imgPath)
            imgPath = imgPath + "\**\*.fit"

        else:
            imgPath = str(imgPath)  
            imgPath = imgPath + "/**/*.fit"
                      
        imageFiles = glob.glob(imgPath, recursive=True)


        for file in imageFiles:
            if "@Focus" not in file:
                imageTS = os.path.getmtime(file)
                difSec = round(abs(imageTS - currentTS), 0)
                if difSec < 1800:
                    if difSec < newestImageDif:
                        newestImageDif = difSec
                        newestImageName = file

        if not newestImageName:
            timeStamp("No recent imaging activity found.")
            return "Fail"        
        timeStamp("Recent imaging activity detected.")
        
        if sys.platform == "win32":
            newestImageName = newestImageName.replace("\\", "\\\\")
        
        timeStamp("Attempting to open image.")
        TSXSend('ccdsoftCameraImage.Path = "' + newestImageName + '"')
        
        output = TSXSend("ccdsoftCameraImage.Open()")

        if output != "0":
            writeNote("SkyX was unable to open file.")
            return "Fail"

        targRA = TSXSend('ccdsoftCameraImage.FITSKeyword("OBJCTRA")')
        targDec = TSXSend('ccdsoftCameraImage.FITSKeyword("OBJCTDEC")')
        if not targRA:
            writeNote("Unable to determine target.")
            return "Fail"

        raHour, raMin, RAsec = targRA.split(" ")
        decDeg, decMin, decSec = targDec.split(" ")

        targ = (raHour + 'h ' + raMin + 'm ' + RAsec + 's, ' + \
                decDeg + 'd ' + decMin + 'm ' + decSec + 's"')

        if "ReferenceError" in str(TSXSend('sky6StarChart.Find("' + targ + ')')):
            timeStamp("Target not found.")
            return "Fail"

        
        TSXSend("ccdsoftCameraImage.Close()")
       
        # Were we guiding?
        guidePath = TSXSend('ccdsoftAutoguider.PropStr("m_csAutoSavePath")')

        guidePath = os.path.abspath(guidePath)

        guidePath = pathlib.Path(guidePath)


        if sys.platform == "win32":
            guidePath = str(guidePath)
            guidePath = guidePath + "\**\\"

        else:
            guidePath = str(guidePath)  
            guidePath = guidePath + "/**/"
                      
        guideFiles = glob.glob(guidePath, recursive=True)

        currentTS = time.time()
        newestImageDif = 14400
        newestImageName = ""
        guiding = "No"

        if guideFiles:
            imageTS = os.path.getmtime(guideFiles[-1])
            difSec = round(abs(imageTS - currentTS), 0)
            if difSec < 7200:
                if difSec < newestImageDif:
                    guiding = "Yes"

        if guiding == "Yes":
            writeNote("Evidence of recent guiding.")
        else:
            writeNote("No evidence of recent guiding.")


        # Are we focusing? If so, @Focus2 or @Focus3?
        currentTS = time.time()
        newestImageDif = 14400
        newestImageName = ""

        imgPath = TSXSend('ccdsoftCamera.PropStr("m_csAutoSavePath")')

        imgPath = os.path.abspath(imgPath)
        imgPath = pathlib.Path(imgPath)

        
        if sys.platform == "win32":
            imgPath = str(imgPath)
            imgPath = imgPath + "\**\\"

        else:
            imgPath = str(imgPath)  
            imgPath = imgPath + "/**/"
       
        imageFiles = glob.glob(imgPath, recursive=True)

        for file in imageFiles:
            if "@Focus" in file:
                imageTS = os.path.getmtime(file)
                difSec = round(abs(imageTS - currentTS), 0)
                if difSec < 7200:
                    if difSec < newestImageDif:
                        newestImageDif = difSec
                        newestImageName = file

        if "@Focus2" in newestImageName:
            writeNote("Most recent focusing used @Focus2")
            autoFocus = "Two"
        elif "@Focus3" in newestImageName:
            writeNote("Most recent focusing used @Focus3")
            autoFocus = "Three"
        else:
            writeNote("No evidence of autofocus (@F2 or @F3) use.")
            autoFocus = "No"


        # Test the devices
        mountGood = "Yes"
        imagerGood = "Yes"
        guiderGood = "Yes"
        focuserGood = "Yes"

        # Can we connect to the mount?
        timeStamp("Attempting to connect to mount.")
        TSXSend("sky6RASCOMTele.Connect()")
        time.sleep(10)
        if (TSXSend("sky6RASCOMTele.IsConnected") == "0"):
            writeNote("Sorry. Mount will not connect.")
            mountGood = "No"
        else:
            writeNote("Mount appears to be connected.")
            
        # Can we connect to the camera?
        timeStamp("Attempting to connect to imaging camera.")
        status = camConnect("Imager")
        if (status == "Success"):
            writeNote("Camera appears to be connected.")
        else:
            writeNote("Camera will not connect.")
            imagerGood = "No"

        # Can we connect to the guider?
        if guiding == "Yes":
            timeStamp("Attempting to connect to guide camera.")
            status = camConnect("Guider")
            if (status == "Success"):
                writeNote("Guider appears to be connected.")
            else:
                writeNote("Guider will not connect.")
                guiderGood = "no"

        # How about the focuser?
        if autoFocus != "No":
            timeStamp("Attempting to connect to the focuser.")
            status = TSXSend("ccdsoftCamera.focConnect()")
            if (status == "0"):
                writeNote("Focuser appears to be connected.")
                focPosition = TSXSend("ccdsoftCamera.focPosition")
                writeNote("Current focuser position appears to be: " + focPosition)
                writeNote("Testing focuser motion.")
                TSXSend("ccdsoftCamera.focMoveIn(10)")
                time.sleep(1)
                TSXSend("ccdsoftCamera.focMoveOut(10)")
                time.sleep(1)
                newFocPosition = TSXSend("ccdsoftCamera.focPosition")
                if newFocPosition == focPosition:
                    writeNote("Focuser appears to move correctly.")
                else:
                    writeNote("Focuser motion appears inconsistant.")
                    focuserGood = "no"
            else:
                writeNote("Focuser will not connect.")
                focuserGood = "no"
 
        # If there are any gear problems, try to shutdown safely. 
        if (mountGood != "Yes") or (imagerGood != "Yes") or (guiderGood != "Yes") or (focuserGood != "Yes"):
            timeStamp("There are un-recoverable problems with one or more devices.")

            if mountGood == "Yes":
                timeStamp("Attempting to turn off sidereal drive.")
                if TSXSend("SelectedHardware.mountModel") !=  "Telescope Mount Simulator":
                    writeNote("Attempting to turn off sidereal drive.")
                    TSXSend("sky6RASCOMTele.SetTracking(0, 1, 0 ,0)")
                else:
                    writeNote("Mount simulator detected.")
            else:
                writeNote("Uncertain of mount's status.")

            if imagerGood == "Yes":
                timeStamp("Attempting to turn off camera's tec and disconnect.")
                camDisconnect("Imager")

            return "Fail"
         
        else:
            timeStamp("System appears to be up & running.")

        # Attempt to re-point the mount, focus & restart guiding.
        CLSlew(targ, "0")
        
        if autoFocus == "Three":
            if atFocus3("NoRTZ", "0") == "Fail":
                timeStamp("There was an error on focus. Stopping script.")
                softPark()

        if autoFocus == "Two":
            if atFocus2(targ, "0") == "Fail":
                timeStamp("There was an error on focus. Stopping script.")
                softPark()

        # Find a guide star 
        if guiding == "Yes":
            takeImage("Guider", "5", "0", "NA")
            AGStar = findAGStar()
            if "Error" in AGStar:
                softPark()
            XCoord,YCoord = AGStar.split(",")
            startGuiding("5", "0", XCoord, YCoord)
    
            # Hang out to give the guider a chance to settle
            time.sleep(30)
    
        # Let the crash detector (which called this) know that everything appears
        # to be back on track.
        return "Success"

    return "Fail"


results = resurrectTest()

print(results)

