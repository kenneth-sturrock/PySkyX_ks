#!/usr/bin/env python3

from library.PySkyX_ks import *

import time
import sys
import os

# Insert your test code here.


myArray = [1, 2, 3, 4, 5]

result = calcRMS(myArray)

print(result)

