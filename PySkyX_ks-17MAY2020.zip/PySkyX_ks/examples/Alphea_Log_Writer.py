#!/usr/bin/env python3

from datetime import datetime
from library.PySkyX_ks import *

# Define an easier carriage return character
CR = "\n"

# Get the current time/date elements
Year, Month, Day, Hour, Minute, Second = datetime.now().strftime("%Y:%m:%d:%H:%M:%S").split(":")

# Turn them into numbers
Year = int(Year)
Month = int (Month)
Day = int(Day)
Hour = int(Hour)
Minute = int(Minute)
Second = int(Second)

# Turn these into decimals that can be added to an hour value
decMinute = Minute / 60
decSecond = Second / 3600

# Assemble the decimal hour
decTime = int(Hour) + decMinute + decSecond

# Convert the current time into a Julian Date
JD = GregToJD(Year, Month, Day, decTime)

# Subtract the December 31, 2899 at noon value
timeCount = JD - 2415020.0

# Get the mount's current coordinates.
TSXSend("sky6RASCOMTele.GetRaDec()")

mntDecDeg = float(TSXSend("sky6RASCOMTele.dDec"))

# Convert hours to degrees
mntRAhrs = float(TSXSend("sky6RASCOMTele.dRa"))
mntRAdeg = float(mntRAhrs) * 15.041067

# Convert degrees to radians
mntRArad = mntRAdeg * (3.14159265359 / 180)
mntDecRad = mntDecDeg * (3.14159265359 / 180)

# Change this to reflect the path of the file
outPath = "/Users/ks/Desktop/Alphea.txt"

# Open the Path
outFile = open(outPath,"w")

# Write the data elements
outFile.write(str(timeCount) + CR)
outFile.write(str(mntRArad) + CR)
outFile.write(str(mntDecRad) + CR)

# Close it out
outFile.close()


