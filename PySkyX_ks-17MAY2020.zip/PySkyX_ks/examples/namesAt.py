#!/usr/bin/env python3

from library.PySkyX_ks import *





namesAt("WDS-2018 AC 15", 5)


