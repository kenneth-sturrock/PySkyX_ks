#!/usr/bin/env python3

#
# This is under development
#
from library.PySkyX_ks import *

import time
import sys
import os

riseTimes = []
transitTimes = []
setTimes = []


targets = sys.argv

del targets[0]

numTargets = len(targets) 

for target in targets:

    if targExists(target) == "Yes":
        results = targRiseSetTimes(target, str(30))

        riseTime,transitTime,setTime=results.split(" -> ")
        
        hours,minutes=riseTime.split(":")
        hours = int(hours)
        minutes = int(minutes)
        results = HMSToDec(hours, minutes, 0)
        decTime = round(results[3], 3)
        riseTimes.append(decTime)

        hours,minutes=transitTime.split(":")
        hours = int(hours)
        minutes = int(minutes)
        results = HMSToDec(hours, minutes, 0)
        decTime = round(results[3], 3)
        transitTimes.append(decTime)

        hours,minutes=setTime.split(":")
        hours = int(hours)
        minutes = int(minutes)
        results = HMSToDec(hours, minutes, 0)
        decTime = round(results[3], 3)
        setTimes.append(decTime)

    else:
        print("    ERROR: " + target + " not found in SkyX database.")

print("Target\tRise\tTransit\tSet")
print("------\t----\t-------\t---")

for index,target in enumerate(targets):

    print(target + "\t" + str(riseTimes[index]) + "\t" + str(transitTimes[index]) + "\t" + str(setTimes[index]))


