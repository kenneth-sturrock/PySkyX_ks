These examples must be run from the directory which contains the "library" subdirectory. In other words, if you haven't moved them, copy these examples to the parent directory above this one before you run them.



