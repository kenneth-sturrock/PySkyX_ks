#!/usr/bin/env python3
#

from library.PySkyX_ks import *

switchPower(0, "status")
switchPower(1, "on")
switchPower(1, "status")
switchPower(2, "status")
switchPower(3, "status")
