#!/usr/bin/env python3
#
# Hang out until a target can be solved with Image Link. Check every 15 minutes and refocus based on temperature 
# in the run_target INI file or 45 minutes.
#
#
# This was originally written for a friend of mine who wanted to delay run_target's start for late-rising 
# objects, which had to get past some trees. Normally run_target will wait until an object rises, but it
# wasn't meant to wait really long times with the result that focus may drift and, by the time the imaging
# run starts, the rig may be out of focus.
#
# Another approach is to tell the rig to image a different target, with an estimated imaging time chosen to
# allow the late-rising target to clear the trees. That way, you'd get data on multiple targets. 
#
# Regardless, if you use this program or stacked run_target-2 commands, you'd seperate the commands with a
# semi-colon (UNIX/Windows Power Shell. Use "&" with Windows CMD).
#
# Ken Sturrock
# June 11, 2025
#




####################
# Import Libraries #
####################

from library.PySkyX_ks import *

import time
import sys
import os
import datetime


results = iniChk()

altLimit = results[0]
defaultFilter = results[1]
focusStyle = results[4]
tempChangeLimit = results[5]

# Is there a current obstruction? Assume yes until proven otherwise.
obstruction = "Yes"

retryCount = 0

#############
# Functions #
#############

def Park():
#
# This is just like hardPark() except it doesn't exit at the end so that the user
# can take control and we don't run any subsequent commands.
#

    TSXSend("sky6StarChart.DocumentProperty(0)")
    latitude = TSXSend("sky6StarChart.DocPropOut")
    
    if float(latitude) < 0:
        writeNote("Pointing mount to the south.")
        slew("HIP112405")
    else:
        writeNote("Pointing mount to the north.")
        slew("kochab")

    if "Paramount" in TSXSend("SelectedHardware.mountModel"):
        if not "Error" in TSXSend("sky6RASCOMTele.ParkAndDoNotDisconnect()"):
            timeStamp("Paramount moved to park position.")
        else:
            timeStamp("No park position set. Stopping sidereal motor.")
            TSXSend("sky6RASCOMTele.SetTracking(0, 1, 0 ,0)")
    else:
        if TSXSend("SelectedHardware.mountModel") !=  "Telescope Mount Simulator":
            writeNote("Turning off sidereal drive.")
            TSXSend("sky6RASCOMTele.SetTracking(0, 1, 0 ,0)")

    timeStamp("Resetting camera defaults.")

    TSXSend("ccdsoftCamera.ExposureTime = 5")			
    TSXSend("ccdsoftCamera.AutoSaveOn = true")
    TSXSend("ccdsoftCamera.Frame = 1")
    TSXSend("ccdsoftCamera.Delay = 0")
    TSXSend("ccdsoftCamera.Subframe = false")

    TSXSend("ccdsoftAutoguider.ExposureTime = 5")
    TSXSend("ccdsoftAutoguider.AutoguiderExposureTime = 5")
    TSXSend("ccdsoftAutoguider.AutoSaveOn = false")
    TSXSend("ccdsoftAutoguider.Frame = 1")
    TSXSend("ccdsoftAutoguider.Delay = 0")
    TSXSend("ccdsoftAutoguider.Subframe = false")

    if str(TSXSend('ccdsoftCamera.PropStr("m_csObserver")')) ==  "Ken Sturrock":
        if str(TSXSend("SelectedHardware.cameraModel")) == "QSI Camera  ":
            TSXSend("ccdsoftCamera.TemperatureSetPoint = 1")
            TSXSend("ccdsoftCamera.FilterIndexZeroBased = 0")
            TSXSend("ccdsoftCamera.ExposureTime = 10")
            TSXSend("ccdsoftCamera.RegulateTemperature = false")


        if str(TSXSend("SelectedHardware.cameraModel")) == "Camera Simulator":
            TSXSend("ccdsoftCamera.FilterIndexZeroBased = 0")

    camDisconnect("Imager")
    camDisconnect("Guider")

    timeStamp("System Parked.")

    # For those so blessed
    domeStop()

    timeStamp("System parked. Press CONTROL-C to break out and again to stop the next command.")
    garbage = input()


def slewToFocusPoint():
# Unleash the mount if necessary & slew
    if TSXSend("sky6RASCOMTele.IsParked()") == "true":
        TSXSend("sky6RASCOMTele.Unpark()")

    if TSXSend("SelectedHardware.mountModel") !=  "Telescope Mount Simulator":
        TSXSend("sky6RASCOMTele.SetTracking(1, 1, 0 ,0)")

    TSXSend('sky6RASCOMTele.SlewToAzAlt(90, 75, "Focus Zone")')

    time.sleep(2)



def focusIt():
#
# I don't use the normal routines in PySkyX because I don't want a CLS back.
#
    if TSXSend("ccdsoftCamera.ImageUseDigitizedSkySurvey") != "1":
        if TSXSend("SelectedHardware.filterWheelModel") != "<No Filter Wheel Selected>":
            TSXSend("ccdsoftCamera.filterWheelConnect()")	
            TSXSend("ccdsoftCamera.FilterIndexZeroBased = " + defaultFilter) 

            if focusStyle == "Two":
                result = TSXSend("ccdsoftCamera.AtFocus2()")
            else:
                result = TSXSend("ccdsoftCamera.AtFocus3(3, true)")

            if "Error" in result:
                timeStamp("Focus failed: " + result)
                Park()
    else:
        writeNote("Simulated Focus")



######################
# Main Program Start #
######################

argvLen = len(sys.argv)

if (argvLen < 2):
    target = input("Please enter target name: ")
else:
    target = sys.argv[1]

if targExists(target) == "No":
    writeError("" + target + " not found in SkyX database.")
    Park()

print("     DATE: " + datetime.date.today().strftime("%Y" + "-" + "%B" + "-" + "%d"))

timeStamp("Target is " + target + ".")

# Wait out the sun.
isDayLight()

currentHA = targHA(target)
currentAlt = targAlt(target) 

if currentAlt < altLimit and currentHA < 0:
#
# This is where we do the methodical wait for the target to rise
#
# Every half hour we refocus high in the sky & come back
#
    targTimes = targRiseSetTimes(target, altLimit)
    riseTime = targTimes[0]
    riseHours,riseMinutes = riseTime.split(":")
    nowHours,nowMinutes = time.strftime("%H:%M").split(":")
    nowDec = HMSToDec(nowHours, nowMinutes, 0)
    nowDec = nowDec[3]
    riseDec = HMSToDec(riseHours, riseMinutes, 0)
    riseDec = riseDec[3]
    
    if (riseDec < nowDec):
    #
    # In case we span midnight, pad the hours.
    #
        riseDec = riseDec + 24

    waitDec = riseDec - nowDec
    waitSec = int((waitDec * 3600) + 60)

    reFocusLoops = int(waitSec / 1800)

    remanderSecs = waitSec - (1800 * reFocusLoops)

    timeStamp("Waiting...")


    for loop in range(reFocusLoops):
        
        time.sleep(1800)

        timeStamp("Touching-up Focus.")

        slewToFocusPoint()

        focusIt()

    time.sleep(remanderSecs)

while obstruction == "Yes":
#
# This is the final check - can we actually IL the target? 
#

    if TSXSend("SelectedHardware.mountModel") !=  "Telescope Mount Simulator":
    #
    # Turn on tracking
    #
        TSXSend("sky6RASCOMTele.SetTracking(1, 1, 0 ,0)")

        slew(target)

        takeImage("Imager", "10", "0", defaultFilter)
    
        if "rror:" in getStats():

            timeStamp("Target appears to be obscured.")
    
            if retryCount > 2:
            #
            # So, here we are half an hour after the altitude specified and we still can't see 
            # a target. Time to bail.
            #
                timeStamp("Ending after repeated Image Link failures.")
                Park()
            else:
                retryCount = retryCount + 1
                timeStamp("Waiting an additional ten minutes.")
                time.sleep(600)
    
        else:
            obstruction = "No"

        # Clean up the Image Link Photos
        dirName,fileName = os.path.split(TSXSend("ccdsoftCameraImage.Path"))
        orgImgName = os.path.splitext(fileName)[0]
        if os.path.exists(dirName + "/" + orgImgName + ".SRC"):
            os.remove(dirName + "/" + orgImgName + ".SRC")
        if os.path.exists(dirName + "/" + orgImgName + ".fit"):
            os.remove(dirName + "/" + orgImgName + ".fit")

    else:
        writeNote("Simulator in use - IL confirmation skipped.")
        obstruction = "No"



print(" ")
print("---")
print(" ")
