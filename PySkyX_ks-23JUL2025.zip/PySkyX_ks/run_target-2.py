#!/usr/bin/env python3
#
# Run an automated session on SkyX.
#
# In addition to activating the TCP Server, you also have to switch on "TCP socket closing"
# under SkyX's Preferences -> Advanced as well as turn off the javascript debugger.
#
# Syntax:
#
#       ./run_target-2 m51 5x300 5x300 5x300 5x300
#
# Second camera is activated with the "-r" option followed by the IP address and port
# of the second SkyX instance:
#
#       ./run_target-2 m51 5x300 5x300 5x300 5x300 -r 10.0.1.11:3040 3x240 3x240 3x240 3x240
#
# You can also add extra non-dithered frames to each set with an addition "x". For example:
#
#       ./run_target-2 m51 5x300x2 5x300 5x300 5x300
#
# will cause an LLRGB LLRGB pattern.
#
# These is a documentation file. If you haven't please consider reading it.
#
# Ken Sturrock
# June 8, 2025 
#


####################
# Import Libraries #
####################

from library.PySkyX_ks import *

import time
import sys
import os
import datetime



###################################################
#                                                 #
# Script set variables - Don't mess with them.    #
#                                                 #
# User-defined variables are now in the INI file. #
#                                                 #
###################################################

filterNumC1 = 0
filterNumC2 = 0
perFilC1 = []
perFilC2 = []
numExpC1 = []
numExpC2 = []
expDurC1 = []
expDurC2 = []
totalExpC1 = 0
totalExpC2 = 0
numDupC1 = []
numDupC2 = []
dupGoalC1 = 1
dupGoalC2 = 1
expCountC1 = 1
expCountC2 = 1
totalSecC1 = 0
totalSecC2 = 0
numSets = 0
numSets1 = 0
numSets2 = 0
lastDitherFilter = 1000

altLimit = 0
defaultFilter = 0
guiderDelay = 0
guiderExposure = 0
focusStyle = 0
tempChangeLimit = 1
flipAngle = 0
unGuidedSettle = 0
asfLocation = "."


####################
# Define Functions #
####################


def chkTarget():
#
# This validates the target and ensures that it is up & that it's night.
#
    writeNote("Target is " + target + ".")

    if targExists(target) == "No":
        writeError("" + target + " not found in SkyX database.")
        softPark()
    
    isDayLight()

    currentHA = targHA(target)
    currentAlt = targAlt(target) 

    if currentAlt < altLimit and currentHA > 0:
        timeStamp("Target " + target + " is " + str(round(currentAlt, 2)) + " degrees high.")
        timeStamp("Target " + target + " has sunk too low.")
        softPark()


    if currentAlt < altLimit and currentHA < 0:
    # This time mish-mash looks more elegant than just checking every five minutes but it's not.
    #
        targTimes = targRiseSetTimes(target, altLimit)
        riseTime = targTimes[0]
        riseHours,riseMinutes = riseTime.split(":")
        
        nowHours,nowMinutes = time.strftime("%H:%M").split(":")
        nowDec = HMSToDec(nowHours, nowMinutes, 0)
        nowDec = nowDec[3]
    
        riseDec = HMSToDec(riseHours, riseMinutes, 0)
        riseDec = riseDec[3]
   
        if (riseDec < nowDec):
        #
        # In case we span midnight
        #
            riseDec = riseDec + 24

        waitDec = riseDec - nowDec
        waitSec = int((waitDec * 3600) + 60)
    
        timeStamp("Waiting " + str(round(waitDec,2)) + " hours for target to rise.")
    
        time.sleep(waitSec)

        timeStamp("Checking target altitude.")

 

def doAnImage(whichCamera, exposureTime, FilterNum):
#
# This function performs the general steps required to take 
# an image. By default, it doesn't mess with the delay and
# only manipulates the camera. It does a follow-up on the
# tracking.
#

    if whichCamera == 1:
    #
    # Is this the primary/local camera?
    #

        if TSXSend('ccdsoftCamera.PropStr("m_csObserver")') == "Ken Sturrock":
        #
        # This is all customization for me. Feel free to set it up for yourself.
        #
        # We're going to toggle the QSI to use high quality mode for a real image.
        #
            if TSXSend("SelectedHardware.cameraModel") == "QSI Camera  ":
                TSXSend('ccdsoftCamera.setPropStr("m_csExCameraMode", "Higher Image Quality")')
                writeNote("Setting QSI Camera to high quality mode.")
    
        if takeImage("Imager", exposureTime, "NA", FilterNum) == "Success":
    
            if TSXSend('ccdsoftCamera.PropStr("m_csObserver")') == "Ken Sturrock":
            #
            # Toggle QSI back to fast mode for focusing/CLS/etc
            #
                if TSXSend("SelectedHardware.cameraModel") == "QSI Camera  ":
                    TSXSend('ccdsoftCamera.setPropStr("m_csExCameraMode", "Faster Image Downloads")')
                    writeNote("Setting QSI Camera to faster download mode.")

            if guiderExposure != "0":
            #
            # Are we guiding?
            #
                if isGuiderLost(setLimit) == "Yes":
                    #
                    # If the guider looks lost, try it again
                    #
                    writeNote("Double Checking Guider.")
                    time.sleep(5)
                    if isGuiderLost(setLimit) == "Yes":
                    #
                    # Is guider lost two checks in a row or was in a one-off?
                    #                    
                        writeError("Guider looks lost")
                        return "Fail"
                    else:
                        writeNote("Guiding is questionable.")
                else:
                    writeNote("Guider Tracking.")


            timeStamp("Local Camera Statistics:")

            if getStats() == "Fail":
            #
            # Print statistics or complain if we can't plate solve.
            #
                return "Fail"

            if (TSXSend("ccdsoftCamera.ImageReduction") == "2"):
            #
            # This routine is designed to complement the PySkyX_ks/Run_target-2 capability
            # to use the built-in TSX image calibration (dark/flat/bias) capability.
            # It renames the files to a PixInsight style format and discards the uncalibrated
            # version. AFAIK, nobody uses this.
            #
                Path = TSXSend("ccdsoftCameraImage.Path")
                dirName,fileName = os.path.split(Path)
                orgImgName = os.path.splitext(fileName)[0]            
                currentRGName = TSXSend('ccdsoftCamera.PropStr("m_csCalGroupName")')
    
                if currentRGName != "Imager":
                #
                # If the RG is the default "Imager" it's because we didn't really
                # calibrate it properly so let's not bother.
                #
                    for scrapFile in glob.glob(dirName + "/" + "*Uncalibrated*.fit"):
                        if os.path.exists(scrapFile):
                            os.remove(scrapFile) 
    
                            # rename the calibrated image to indicate calibration
                            if os.path.exists(Path):
                                calPath = Path.replace(".fit", "_c.fit")
                                os.rename(Path, calPath)
                else:
                #
                # If we're using the default "Imager" RG then it probably isn't really
                # calibrated properly so we're going to clobber the calibrated
                # copy and rename the uncalibrated copy back without the "_c" suffix.
                #
                    uncalPath = Path.replace(".fit", "Uncalibrated.fit")
                    # Double check to make sure both files really exist.
                    if os.path.exists(Path):
                        if os.path.exists(uncalPath):
                            os.remove(Path)
                            os.rename(uncalPath, Path)
    
            return "Success"
    
        else:
            return "Fail"


    else:
    #
    # We must be using the second/remote camera. AFAIK, nobody uses this.
    #
    # The camera #2 code is seriously stripped down compared to #1.
    # There is no guider check and the stats are run seperately.
    #
        if takeImageRemote(camTwoIP, "Imager", exposureTime, "NA", FilterNum) == "Success":

            getStatsRemote(camTwoIP, "Imager")

            if getStats() == "Fail":
            #
            # Print statistics or report if we can't plate solve.
            #
                return "Fail"
            else:
                return "Success"


def focusAndDither(forceFocus, doDither):
#
# This routine runs the appropriate focus on both cameras (if applicable)
#
# Remember that this can get a bit mind-bending: This focus routine calls
# other focus routines in the library which may, in turn, call another focusing 
# routine. This whole thing is handled a bit inconsistantly with @F3 on two 
# cameras. Get your aspirin.
#
# The forceFocus flag forces a focus or leaves it up to the temperature & timing logic.
# The doDither flag forces a dither ("Yes") independent of focus. "No" prohibits
# a dither (for example an initial focus) and "Maybe" will dither only if the temp & time
# logic decides to focus.
#
# Parameters must be CaPiToLiZeD
#


    # This is a kludge, but I'm too lazy to pass them in & out.
    global lastTemp
    global lastSeconds
    global lastDitherFilter


    currentTemp = getTemp()
    currentSeconds = round(time.monotonic(),0)
    
    if focusStyle != 0:
    #
    # Is the temperature, elapsed time or a flag going to force us to focus? 
    # Note that this is set to refocus every half degree of change (or 45 minutes) because my SVQ seems to need it. Please
    # change the temperature limit (variable above) or the time (in seconds) below if you see the need.
    #
    # Obviously, if we're not going to autofocus (style = zero) then skip it.
    #
        if (abs(lastTemp - currentTemp) > tempChangeLimit ) or ((currentSeconds - lastSeconds) > 2700) or (forceFocus == "Yes"):

            writeGap()
            writeNote("Current Temperature: " + str(currentTemp))
    
            if guiderExposure != "0":
            #
            # Turn off guiding
            #
                stopGuiding()
                    
            if camTwoIP == "none":
            #
            # Deal with camera one
            #
                if focusStyle == 2:
                #
                # Use @F2
                #
                    if atFocus2(target, defaultFilter) != "Fail":
                        lastTemp = getTemp()
                        lastSeconds = round(time.monotonic(),0)
                else:
                #
                # or @F3
                #
                    if atFocus3(target, defaultFilter) != "Fail":
                        lastTemp = getTemp()
                        lastSeconds = round(time.monotonic(),0)
    
                if (doDither == "Maybe"):
                #
                # Because we went ahead and focused, change the dither from optional to required.
                #
                    doDither = "Yes"
    
            else:
                if focusStyle == 2:
                    if atFocus2Both(camTwoIP, target, defaultFilter) != "Fail":
                    #
                    # There is incosistancy in focus routine naming. There is a "both" function which
                    # will refocus both cameras with @F2, but not three.
                    #
                        lastTemp = getTemp()
                        lastSeconds = round(time.monotonic(),0)
                else:
                    if atFocus3(target, defaultFilter) != "Fail":
                    #
                    # Focus local camera with @F3
                    #
                        lastTemp = getTemp()
                        lastSeconds = round(time.monotonic(),0)
                
                        #
                        # If we succeded in focusing the local camera, focus the remote camera with @F3.
                        #
                        atFocusRemote(camTwoIP, "Imager", "Three", defaultFilter)
    
                if (doDither == "Maybe"):
                #
                # Because we went ahead and focused, change the dither from optional to required.
                #
                    doDither = "Yes"



    if doDither == "Maybe":

        if (lastDitherFilter == filterNumber):
        #
        # If we're indecisive about dithering when we called this function 
        # then go ahead and dither if the previous dither was on this filter.
        #
        # This will make sure that we dither each rotation of filters.
        #
            doDither = "Yes"
    
    #
    # So, in the end, did we decide to dither for real?
    #               
    if (doDither == "Yes"):
        print("           -----")
        if guiderExposure != "0":
            if (TSXSend("ccdsoftAutoguider.State") == "5"):
            #
            # Since the focus routine didn't already turn it off, let's stop guiding.
            #
                stopGuiding()

        dither()
        lastDitherFilter = filterNumber

    #
    # If we're not guiding and should, restart it.
    # otherwise, settle with a wait if we dithered.
    #
    if (guiderExposure != "0"):
        if (TSXSend("ccdsoftAutoguider.State") != "5"):
            setupGuiding()
    
    elif (doDither == "Yes"):
    #
    # If we're not guiding and we dithered then let's settle.
    #
        timeStamp("Waiting for mount to settle.")
        time.sleep(unGuidedSettle)
       

def houseKeeping():
#
# This covers functions that used to occur between sets but
# are now handled between images.
#
    global lastDitherFilter

    if (filterNumber != (totalFil - 1)) and (currentSet != (totalSetsNeeded)):
    #
    # Only run the housekeeping stuff if we are NOT on the last filter of the last set
    # because there won't be any more images and we're about to shutdown anyway.
    #
    # Remember that the totals show the sum of items, not a count starting with zero.
    #


        # If it is morning, shut it down.
        if setCounter <= numSets:
            isDayLight()
        
        # If the target is low, shut it down.    
        if targAlt(target) < 35 and targHA(target) > 0:
            timeStamp("Target has sunk too low.")
            hardPark()
    
    
        if TSXSend("SelectedHardware.mountModel") !=  "Telescope Mount Simulator":
        #
        # Don't do this on a simulator, because the simulator isn't a GEM.
        #
    
            #
            # This command sends the "Beyond the pole" inquisition.
            #
            TSXSend('sky6RASCOMTele.DoCommand(11, "")')
            if (TSXSend("sky6RASCOMTele.DoCommandOutput") == "1") and (targHA(target) > flipAngle):
            #
            # If the target crossed the meridian, but the mount did not - then flip the mount.
            #
                timeStamp("Flipping the mount.")
    
                if guiderExposure != "0":
                #
                # Stop the guiding. It will get restarted by subsequent focus/dither calls
                #
                    stopGuiding()
                    writeNote("Guiding Stopped.")
    
                writeNote("Using CLS to ensure target alignment.")
                if CLSlew(target, defaultFilter) == "Fail":
                    timeStamp("Error finding target post-flip.")
                    hardPark()
    
                #
                # This forces a focus after a meridian flip in case something mechanical moved.
                #
                # There is no reason to dither since you just changed the FOV by flipping
                #
                focusAndDither("Yes", "No")

                # Go ahead and reset the last dither filters though because we did the
                # equivelent of a dither by flipping the mount.
                lastDitherFilter = filterNumber
                
    
            else:
            #
            # Give the rig a chance to focus & dither, but let the routine's logic
            # make the decision as to whether to do it, or not.
            #
                focusAndDither("Maybe", "Maybe")
    

        else:
        #
        # Just for testing consistancy on the simulator, call the focus routine...
        #
            focusAndDither("Maybe", "Maybe")



    if (filterNumber == 0) and (currentSet == 0):
    #
    # We're reseeding this variable to dither AFTER the first filter of
    # the first set so we don't dither first image out.
    #
        lastDitherFilter = filterNumber


def setupGuiding():
#
# This is a "macro" that calls several simpler functions in 
# order to setup autoguiding.
#

    #
    # This represents the calculated guider settle limit based on a ratio of the main & guider image scales.
    #
    # It gets used by a couple of routines and I was too lazy to pass it each time.
    #
    global setLimit

    writeGap()

    camConnect("Guider")

    stopGuiding()

    time.sleep(1)

    # Take an image of the guider FOV
    takeImage("Guider", guiderExposure, "0", "NA")

    # Pick a decent guide star.
    AGStar = findAGStar()

    if "Error" in AGStar:
    # Not off to a good start....

        cloudWait(defaultFilter)

        if CLSlew(target, defaultFilter) == "Fail":
            timeStamp("There was an error CLSing to Target. Stopping script.")
            hardPark()

        takeImage("Guider", guiderExposure, "0", "NA")

        AGStar = findAGStar()
     
        if "Error" in AGStar:
            writeError("Still cannot find a guide star. Sorry it didn't work out...")
            hardPark()
        else:
            XCoord,YCoord = AGStar.split(",")
    else:    
    # Split the coordinates into separate variables.
        XCoord,YCoord = AGStar.split(",")

    # Do the math to calculate a "good enough" guider error limit.
    setLimit = calcSettleLimit()

    # Do we need to adjust the guider exposure? In theory, the star should not
    # be saturated, but this will also boost the guider exposure time if the 
    # guide star is dim.
    expRecommends = adjAGExposure(guiderExposure, guiderDelay, XCoord, YCoord)
    newGuiderExposure = expRecommends[0]
    newGuiderDelay = expRecommends[1]

    # Start guiding
    startGuiding(newGuiderExposure, newGuiderDelay, XCoord, YCoord)

    # Wait until the guider/mount is settled or lost. If it gets
    # lost then retry it.
    if settleGuider(setLimit) == "Lost":
        writeError("Guiding setup failed.")
        stopGuiding()
                
        cloudWait(defaultFilter)
                
        if CLSlew(target, defaultFilter) == "Fail":
            timeStamp("There was an error CLSing to Target. Stopping script.")
            hardPark()
                
        takeImage("Guider", guiderExposure, "0", "NA")

        AGStar = findAGStar()

        if "Error" in AGStar:
            writeError("Still have problems setting up guider. Exiting.")
            softPark()

        XCoord,YCoord = AGStar.split(",")

        startGuiding(guiderExposure, guiderDelay, XCoord, YCoord)

        if settleGuider(setLimit) == "Lost":
            writeError("Guiding setup failed again.")
            hardPark()




       
######################
# Main Program Start #
######################

writeGap()
timeStamp("Run started")

print("     DATE: " + datetime.date.today().strftime("%Y" + "-" + "%B" + "-" + "%d"))

results = iniChk()

altLimit = results[0]
defaultFilter = results[1]
guiderDelay = results[2]
guiderExposure = results[3]
focusStyle = results[4]
tempChangeLimit = results[5]
flipAngle = results[6]
unGuidedSettle = results[7]

writeNote("SkyX Pro Build Level: " + TSXSend("Application.build"))

if sys.platform == "win32":
    writeNote("Running on Windows.")

if sys.platform == "darwin":
    writeNote("Running on Macintosh.")

if sys.platform == "linux":
	if "rpi" in  os.uname()[2]:
		writeNote("Running on R-Pi.")
	else:
		writeNote("Running on Linux.")


# Turn off guiding functions if no guider chosen in SkyX.
if TSXSend("SelectedHardware.autoguiderCameraModel") == "<No Camera Selected>":
    guiderExposure = "0"

if guiderExposure == "0":
    writeNote("Guiding disabled.")

if TSXSend("SelectedHardware.focuserModel") ==  "<No Focuser Selected>":
    focusStyle = 0

if focusStyle == 0:
    writeNote("Autofocus disabled.")

# For those so blessed
domeStart()


#####################################################################
# Take apart the arguments to figure out what the user wants to do. #
#####################################################################

totalArgs = (len(sys.argv) - 2)

if totalArgs < 1:
#
# If the user hasn't specified command line arguments, fire up the GUI.
#
    timeStamp("Incomplete command line arguments.")
    print("           Syntax: " + sys.argv[0] + " target FxE FxE ...")
    
    print(" ")
    print("----------")
    timeStamp("Launching graphical interface.")

    # Only load the GUI libraries if they need to be used.
    from library.RT_GUI import runGUI
    
    GUIresults = runGUI()
    timeStamp("Closing graphical interface.")
    print("----------")
    print(" ")

    argumentArray = GUIresults[0]
    guiderExposure = GUIresults[1]
    guiderDelay = GUIresults[2]
    focusStyle = GUIresults[3]

else:
    argumentArray = sys.argv



#
# Regardless of GUI or CUI, we now have a consistant argument array, I mean "list"...
#
# The first two positions in the list are the command name, itself, and the target
# so we're going to skip them for this.
#
totalArgs = (len(argumentArray) - 2)

target = argumentArray[1]

camOneExp = []
camTwoExp = []
camTwoIP = "none"


for argIndex, argument in enumerate(argumentArray[2:]):
#
# Step through each argument and evaluate the mess.
#

    if argument == "-r":
    #
    # Rats. We have a "-r" flag indicating a remote
    # camera. This will get uglier...
    #
        if argumentArray[argIndex + 3]:
        #
        # Let's poke ahead and see if the next argument
        # actually exists before comitting to something
        # embarassing.
        #
        # Remember that we're incrementing the index by 3
        # instead of just 1 because we actually started 
        # at position 2 (the third position) in the original
        # list (argumentArray).
        #
        # Yeah. Trying to be Pythonic is nastier than advertised.
        #
            if "." in argumentArray[argIndex + 3]:
            #
            # OK. The next argument does exist. Does it have a "." 
            # which we use as a proxy for an IP address?
            #
                camTwoIP = argumentArray[argIndex + 3]
            else:
                print("Invalid or incomplete IP address specified for second camera.")
                sys.exit()
        else:
            print("Insufficient arguments provided to specify second camera.")
            sys.exit()



    else:
    #
    # We don't have an "-r" but we could have either Camera #1 or #2
    # parameters or even an IP address. We've got to figure that out.
    #
        if "." not in argument:
        #
        # OK, so it's not an IP address for the remote camera.
        #
        # But.... Which camera is this parameter used for?
        #
            if camTwoIP == "none":
            #
            # We haven't yet set an IP address for the remote
            # camera, so this argument must be a parameter for
            # Camera #1.
            #
                camOneExp.append(argument)

            else:
            #
            # Assign this argument to Camera #2
            #
                camTwoExp.append(argument)


#
# Do a reference count for the total filters and 
# figure out the maximum number of filters per set
# to include both cameras.
# 
totalFilC1 = len(camOneExp)
totalFilC2 = len(camTwoExp)
totalFil = max(totalFilC1, totalFilC2)




####################################################
# Is the target valid? Talk about the environment. #
####################################################

writeNote("Checking cameras.")
camConnect("Imager")

if camTwoIP != "none":
    camConnectRemote(camTwoIP, "Imager")

if str(TSXSend("SelectedHardware.mountModel")) ==  "Telescope Mount Simulator":
    writeNote("Simulated Mount.")
else:
    writeNote("Checking sidereal drive.")
    TSXSend("sky6RASCOMTele.SetTracking(1, 1, 0 ,0)")

if camTwoIP != "none":
    writeNote("Remote SkyX Pro Build Level: " + TSXSendRemote(camTwoIP, "Application.build"))

    OS = TSXSendRemote(camTwoIP, "Application.operatingSystem")
    TSXSendRemote(camTwoIP,'sky6RASCOMTele.DoCommand(15, "")')
    Platform = TSXSendRemote(camTwoIP,"sky6RASCOMTele.DoCommandOutput")
          
    if (OS == "1"):
        writeNote("Remote system running on Windows")

    if (OS == "2"):
        writeNote("Remote system running on Macintosh")
                

    if (OS == "3"):
        if (Platform == "arm"):
            writeNote("Remote system running on R-Pi")
        elif (Platform == "arm64"):
            writeNote("Remote system running on Linux (ARM64)")
        else:
            writeNote("Remote system running on Linux")

chkTarget()

#############################################
# Work out the imaging plan and explain it. #
#############################################

print("     PLAN:")

print("           Local Camera")
print("           ------------")

while filterNumC1 < totalFilC1:
#
# Cycle through the camera #1 filters and figure out the parameters.
#
    
    #
    # Start filling in the two-dimensional list for the Camera #1 parameters
    #
    perFilC1.append(camOneExp[filterNumC1])


    if perFilC1[filterNumC1].count("x") == 1:
        num,dur=perFilC1[filterNumC1].split("x")
        dup=1

    if perFilC1[filterNumC1].count("x") == 2:
        num,dur,dup=perFilC1[filterNumC1].split("x")

    if dup == "0":
    #
    # This is done to avoid an embarassing divide by zero error created when the GUI 
    # pads the array
    #
        dup = 1


    numDupC1.append(int(dup))
    numExpC1.append(int(num))
    expDurC1.append(int(dur))

    if numDupC1[filterNumC1] == 1:
        adjExposureNum = numExpC1[filterNumC1]
    else:
        adjExposureNum = (numExpC1[filterNumC1] * numDupC1[filterNumC1])
        numExpC1[filterNumC1] =  (numExpC1[filterNumC1] * numDupC1[filterNumC1])


    if TSXSend("SelectedHardware.filterWheelModel") != "<No Filter Wheel Selected>":
        filName = TSXSend("ccdsoftCamera.szFilterName(" + str(filterNumC1) + ")")
    else:
        filName = "no"
     
    print ("           " + str(adjExposureNum) + " exposures for " + str(expDurC1[filterNumC1]) + " secs. with " + filName + " filter.")
    
    totalExpC1 = totalExpC1 + adjExposureNum
    totalSecC1 = totalSecC1 + (expDurC1[filterNumC1] * adjExposureNum)

    if numExpC1[filterNumC1] > numSets1:
        numSets1 = numExpC1[filterNumC1]
    
    filterNumC1 = filterNumC1 + 1
    
print("           -----")
print("           " + str(totalExpC1) + " total exposures for " + str(round((totalSecC1 / 60), 2)) + " total minutes.")
print("           -----")


if camTwoIP != "none":

    print(" ")
    print("           Remote Camera")
    print("           -------------")

    while filterNumC2 < totalFilC2:

        perFilC2.append(camTwoExp[filterNumC2])

        if perFilC2[filterNumC2].count("x") == 1:
            num,dur=perFilC2[filterNumC2].split("x")
            dup=1

        if perFilC2[filterNumC2].count("x") == 2:
            num,dur,dup=perFilC2[filterNumC2].split("x")
    
        numDupC2.append(int(dup))
        numExpC2.append(int(num))
        expDurC2.append(int(dur))
    
        if numDupC2[filterNumC2] == 1:
            adjExposureNum = numExpC2[filterNumC2]
        else:
            adjExposureNum = (numExpC2[filterNumC2] * numDupC2[filterNumC2])
            numExpC2[filterNumC2] =  (numExpC2[filterNumC2] * numDupC2[filterNumC2])

        if TSXSendRemote(camTwoIP,"SelectedHardware.filterWheelModel") != "<No Filter Wheel Selected>":
            filName = TSXSendRemote(camTwoIP,"ccdsoftCamera.szFilterName(" + str(filterNumC2) + ")")
        else:
            filName = "no"

        print ("           " + str(adjExposureNum) + " exposures for " + str(expDurC2[filterNumC2]) + " secs. with " + filName + " filter.")
        
        totalExpC2 = totalExpC2 + adjExposureNum
        totalSecC2 = totalSecC2 + (expDurC2[filterNumC2] * adjExposureNum)

        if numExpC2[filterNumC2] > numSets1:
            numSets1 = numExpC2[filterNumC2]
    
        filterNumC2 = filterNumC2 + 1
    
    print("           -----")
    print("           " + str(totalExpC2) + " total exposures for " + str(round((totalSecC2 / 60), 2)) + " total minutes.")
    print("           -----")
    print(" ")

if numSets1 >= numSets2:
    numSets = numSets1
else:
    numSets = numSets2

######################################
# Move the mount and start the setup #
######################################

# I do this because, with @F2 and a Paramount, the initial CLS is wasted
if (TSXSend('ccdsoftCamera.PropStr("m_csObserver")') == "Ken Sturrock") and \
        ("Paramount" in TSXSend("SelectedHardware.mountModel")) and \
        (focusStyle == 2):
        slew(target)

# Same with the simulator.
elif TSXSend("SelectedHardware.mountModel") ==  "Telescope Mount Simulator":
    slew(target)

else:
    if CLSlew(target, defaultFilter) == "Fail":
        timeStamp("There was an error on initial CLS. Stopping script.")
        softPark()


if camTwoIP != "none":
    slewRemote(camTwoIP, target)


# These are used in the refocus logic and need to be seeded.
lastTemp = getTemp()
lastSeconds = 0

# Run an initial focus but don't dither.
#
# Guiding has to be set up independently because the focus
# routine only sets up guiding if a dither occured.

if focusStyle == 0:
    # If there is no focuser but we are guiding, setup guiding
    if guiderExposure != "0":
        setupGuiding()
        
    # if there is no focuser and no guiding, wait the specified seconds to settle
    else:
        timeStamp("Waiting for mount to settle.")
        time.sleep(unGuidedSettle)

# if there is a focuser but no guider then wait as a settle
elif guiderExposure == "0":
    timeStamp("Waiting for mount to settle.")
    time.sleep(unGuidedSettle)

else:
#
# if there is a focuser and a guider then focus & setup guiding. Reseed the last dither filter
#
    focusAndDither("Yes", "No")


############################################
# Start the main imaging loop              #
#                                          #
#   Could I revive within me               #
#   Her symphony and song,                 #
#   To such a deep delight                 #
#   ’twould win me,                        #   
#                                          #
#               -Samuel Taylor Coleridge   #
############################################

setCounter = 1 

# This divides the exposures by duplicates to determine the number of sets needed for each camera, then picks
# the larger of the two as the total number of sets we have to loop through to cover everything.
#

totalSetsC1 = [int(exposures / duplicates) for exposures,duplicates in zip(numExpC1, numDupC1)]
totalSetsC2 = [int(exposures / duplicates) for exposures,duplicates in zip(numExpC2, numDupC2)]

if totalSetsC2 and totalSetsC1:
#
# Option #1 - we have two cameras and need to base totalSetsNeeded off of both of them.
#
    totalSetsNeeded = max(max(totalSetsC1), max(totalSetsC2))

elif totalSetsC1:
#
# Option #2 - We only have Camera #1, so set the set loop on it
#
    totalSetsNeeded = max(totalSetsC1)

elif totalSetsC2:
#
# Option #2 - We only have Camera #2 (weird...), so set the set loop on it
#
    totalSetsNeeded = max(totalSetsC2)

else:
    writeError("Mysterious miscount mischief...")
    sys.exit()


for currentSet in range(totalSetsNeeded):
#
# Run through this many sets to capture all exposures & duplicates for all filters.
# The sets start with zero, which is unattractive...
#

    for filterNumber in range(totalFil):
    #
    # Create an index for the maximum number of filters needed in any set
    # for both cameras and cycle through them.
    #
        if (0 <= filterNumber < len(numExpC1)) and (0 <= filterNumber < len(numExpC2)):
        #
        # Option #1 - we have filters left to shoot on both possible cameras.
        #
            numDupTotal = max(numDupC1[filterNumber], numDupC2[filterNumber])

        elif (0 <= filterNumber < len(numExpC1)):
        #
        # Option #2 - we have filters left to shoot on Camera #1.
        #
            numDupTotal = numDupC1[filterNumber]

        elif (0 <= filterNumber < len(numExpC2)):
        #
        # Option #3 - we have filters left to shoot on Camera #2.
        #
            numDupTotal = numDupC2[filterNumber]

        else:
            writeError("Mysterious miscount mischief...")
            sys.exit()

        #
        # Call the housefeeping (flip/focus/dither) routine
        #
        houseKeeping()

        for shot in range(1, numDupTotal + 1):
        #
        # Go ahead and set up a loop for the duplicates.
        #


            ###############################
            # Camera #2 code but no stats #
            ###############################

            if 0 <= filterNumber < len(numExpC2):
            #
            # Do we have an actual exposure for this filter index on Camera 2?
            #
                if numDupC2[filterNumber] >= (shot):
                #
                # Do we have a duplicate value for this filter & camera #2?
                #
                    if (numExpC2[filterNumber] / numDupC2[filterNumber]) > currentSet:
                    #
                    # How many exposures are we supposed to take at this filter location? Is the currentSet counter
                    # larger than the number we are supposed to take for this filter during the entire session? If so, skip it 
                    # because we are done with this filter.
                    #


                        #
                        # Print a pretty banner to let the user know what's happening.
                        #
                        writeGap()
                        writeNote("Starting remote camera image " + str(expCountC2) + " of " + str(totalExpC2) + ".")
                        writeGap()
                        expCountC2 = expCountC2 + 1

                        #
                        # This will take a remote picture asynch so we can move on to the local camera
                        #
                        doAnImage(2, str(expDurC2[filterNumber]), filterNumber) 


            ##################
            # Camera #1 code #
            ##################


            if 0 <= filterNumber < len(numExpC1):
            #
            # Do we have an actual exposure for this filter index on Camera #1
            #
                if numDupC1[filterNumber] >= (shot):
                #
                # Do we have a duplicate value for this filter & camera #1?
                #

                    if (numExpC1[filterNumber] / numDupC1[filterNumber]) > currentSet:
                    #
                    # How many exposures are we supposed to take at this filter location? Is the currentSet counter
                    # larger than the number we are supposed to take for this filter during the entire session? If so, skip it 
                    # because we are done with this filter.
                    #

                        #
                        # Print a pretty banner to let the user know what's happening.
                        #
                        writeGap()
                        writeNote("Starting local camera image " + str(expCountC1) + " of " + str(totalExpC1) + ".")
                        expCountC1 = expCountC1 + 1
                        writeGap()

                        if doAnImage(1, str(expDurC1[filterNumber]), filterNumber) == "Fail":
                        #
                        # Finally! Take the damn picture!
                        # 
                        # But... What if things go wrong? We're only going to check Camera #1
                        # for problems since, presumably, sky/mount/guiding issues will be general
                        # to both cameras.
                        #
                            writeError("Camera problem or clouds..")

                            if guiderExposure != "0":
                            #
                            # Stop Guiding
                            #
                                stopGuiding()
            
                            # This routine will check for clouds and only release if the sky is clear
                            # otherwise, it will park in about half an hour.
                            cloudWait(defaultFilter)
        
                            if CLSlew(target, defaultFilter) == "Fail":
                            #
                            # Take us back to target, shut it down if this fails.
                            #
                                timeStamp("There was an error CLSing to Target. Stopping script.")
                                hardPark()
            
                                if guiderExposure != "0":
                                #
                                # If we are guiding then re-start guiding
                                # this is similar but slightly different than the
                                # function above because we don't want yet another retry in case
                                # of yet another failure.
                                #    
                                    takeImage("Guider", guiderExposure, "0", "NA")
                                    AGStar = findAGStar()
                                    if "Error" in AGStar:
                                        writeError("Still have problems setting up guider. Exiting.")
                                        softPark()
                                    XCoord,YCoord = AGStar.split(",")
                                    setLimit = calcSettleLimit()
                                    startGuiding(guiderExposure, guiderDelay, XCoord, YCoord)
                                    if settleGuider(setLimit) == "Lost":
                                        writeError("Unable to setup guiding.")
                                        hardPark()
                                    else:
                                        writeNote("Attempting to move on.")
                                        if doAnImage(str(expDurC1[filterNumber]), filterNumber) == "Fail":
                                        #
                                        # Take a make-up shot and try to get us out of this mess.
                                        #
                                            writeError("There is still a problem.")
                                            hardPark()
                                        else:
                                            writeNote("Resuming Sequence.")


            ###################
            # Camera #2 stats #
            ###################

            if 0 <= filterNumber < len(numExpC2):
            #
            # We're just duplicating the Camera #2 validity steps before running stats. 
            #
                if numDupC2[filterNumber] >= (shot):
                    if numExpC2[filterNumber] > currentSet:

                        #
                        # Is the remote image done?
                        #
                        writeGap()
                        remoteImageDone(camTwoIP, "Imager")
                        TSXSendRemote(camTwoIP,"ccdsoftCamera.Asynchronous = false")
                        timeStamp("Remote Camera Statistics:")
                        getStatsRemote(camTwoIP, "Imager")


# The regular park doesn't shutdown the remote camera.
if camTwoIP != "none":
    writeNote("Disconnecting remote camera.")
    camDisconnectRemote(camTwoIP, "Imager")

hardPark()


