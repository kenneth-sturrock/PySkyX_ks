#!/usr/bin/env python3
#
# Quick and dirty script to measure filter offsets. Specify the filter number (starting with 0 (zero)) as an argument
#
# If the comparison filter is not in slot zero, then change baseFilterNum, below. You can tell it the comparison
# filter on the command line or by answering the prompt.
#
# January 10, 2026
#



from library.PySkyX_ks import *
import sys
import statistics
import time

baseFilterNum = 0
filterNum = 0
result = " "
cycleOffsetMedians = []
cycleOffsetMeans = []


if (len(sys.argv) == 1):
    timeStamp("Please specify filter number to compare.")
    sys.exit()

filterNum = sys.argv[1]
filterNum = int(filterNum)

if filterNum == baseFilterNum:
    timeStamp("Comparison set to use same filter.")
    sys.exit()

print("---")


for cycle in range(1,6):

    focPosition = 0
    focPositions = []

    timeStamp("Starting cycle: " + str(cycle) + " of 5.")


    timeStamp("Slewing.")
    TSXSend("sky6RASCOMTele.SlewToAzAlt(270, 80, 'Focus Zone');")

    filters = [baseFilterNum, filterNum, baseFilterNum, filterNum, baseFilterNum, filterNum, baseFilterNum, filterNum, baseFilterNum]

    if TSXSend("SelectedHardware.mountModel") !=  "Telescope Mount Simulator":
    
        for filterSlot in filters:      
    
            TSXSend("ccdsoftCamera.FilterIndexZeroBased = " + str(filterSlot)) 
    
            timeStamp("Focusing through " + TSXSend("ccdsoftCamera.szFilterName(" + str(filterSlot) + ")") + " filter.")
    
            if (filterSlot == 0):
                TSXSend("ccdsoftCamera.setPropDbl('m_daf2CalibrationExposureTime', '0.04')")
    
            if (filterSlot == 1):
                TSXSend("ccdsoftCamera.setPropDbl('m_daf2CalibrationExposureTime', '0.1')")
    
            if (filterSlot == 2):
                TSXSend("ccdsoftCamera.setPropDbl('m_daf2CalibrationExposureTime', '0.3')")
    
            if (filterSlot == 3):
                TSXSend("ccdsoftCamera.setPropDbl('m_daf2CalibrationExposureTime', '0.8')")
    
            if (filterSlot == 4):
                TSXSend("ccdsoftCamera.setPropDbl('m_daf2CalibrationExposureTime', '1.8')")
    
            if (filterSlot == 5):
                TSXSend("ccdsoftCamera.setPropDbl('m_daf2CalibrationExposureTime', '2.0')")
        
            if (filterSlot == 6):
                TSXSend("ccdsoftCamera.setPropDbl('m_daf2CalibrationExposureTime', '5.0')")
    	
            if (filterSlot == 7):
                TSXSend("ccdsoftCamera.setPropDbl('m_daf2CalibrationExposureTime', '0.4')")

            result = TSXSend("ccdsoftCamera.AtFocus2()")
    
            if "Process aborted." in result:
                TSXSend("ccdsoftCamera.setPropDbl('m_daf2CalibrationExposureTime', '0.04')")
                sys.exit()
    
            if "Error" in result:
                writeError("@Focus2 Failed. Pausing 30 seconds.")
                writeNote("Press Control-C to abort.")
                time.sleep(30)
                writeNote("Attempting to recover focus with @Focus3.")
                result = TSXSend("ccdsoftCamera.AtFocus3(5, true)")
        
                if "Process aborted." in result:
                    TSXSend("ccdsoftCamera.setPropDbl('m_daf2CalibrationExposureTime', '0.04')")
                    sys.exit()
        
                if "Error" in result:
                    writeError("@Focus3 failed. Waiting 5 minutes for a final re-try.")
                    time.sleep(360)
                    timeStamp("Trying @Focus3 again.")
                    result = TSXSend("ccdsoftCamera.AtFocus3(5, true)")
        
                    if "Process aborted." in result:
                        TSXSend("ccdsoftCamera.setPropDbl('m_daf2CalibrationExposureTime', '0.04')")
                        sys.exit()
        
                    if "Error" in result:
                        TSXSend("ccdsoftCamera.setPropDbl('m_daf2CalibrationExposureTime', '0.04')")
                        sys.exit()
 
            TSXSend("ccdsoftCamera.setPropDbl('m_daf2CalibrationExposureTime', '0.04')")
    
            focPosition = int(TSXSend("ccdsoftCamera.focPosition"))
            focTemp = TSXSend("ccdsoftCamera.focTemperature.toFixed(1)")
            timeStamp("Filter " + TSXSend("ccdsoftCamera.szFilterName(" + str(filterSlot) + ")") + " (" + str(filterSlot) + ")"+ " at " + str(focTemp) + "c = " + str(focPosition))

            focPositions.append(focPosition)
    
    else:
        writeNote("Simulator in use.")
    
        focPositions.append(5000)
        focPositions.append(4000)
        focPositions.append(5100)
        focPositions.append(4000)
        focPositions.append(5000)
        focPositions.append(4100)
        focPositions.append(4900)
        focPositions.append(3700)
        focPositions.append(5000)
    
    
    medBase = statistics.median([focPositions[0], focPositions[2], focPositions[4], focPositions[6], focPositions[8]])
    medFilter = statistics.median([focPositions[1], focPositions[3], focPositions[5], focPositions[7]])
    meanBase = statistics.mean([focPositions[0], focPositions[2], focPositions[4], focPositions[6], focPositions[8]])
    meanFilter = statistics.mean([focPositions[1], focPositions[3], focPositions[5], focPositions[7]])
    medOffset = (medFilter - medBase)
    meanOffset = (meanFilter - medBase)

    cycleOffsetMedians.append(medOffset)
    cycleOffsetMeans.append(meanOffset)

    
    writeNote(TSXSend("ccdsoftCamera.szFilterName(" + str(filterNum) + ")") + " Filter")
    writeSpaced("Median Offset = " + str(int(medOffset)))
    writeSpaced("  Mean Offset = " + str(int(meanOffset)))
    print("---")
    

cycleMedianOffset = statistics.median(cycleOffsetMedians)
cycleMeanOffset = statistics.mean(cycleOffsetMeans)
cycleMeanOfMedianOffset = statistics.mean(cycleOffsetMedians)



print(TSXSend("ccdsoftCamera.szFilterName(" + str(filterNum) + ")") + " Median of median offsets: " + str(int(cycleMedianOffset)))
print(TSXSend("ccdsoftCamera.szFilterName(" + str(filterNum) + ")") + " Mean of mean offsets:     " + str(int(cycleMeanOffset)))
print(TSXSend("ccdsoftCamera.szFilterName(" + str(filterNum) + ")") + " Median of mean offsets:   " + str(int(cycleMeanOfMedianOffset)))


print("------")
print("")







