#!/usr/bin/env python3
#
# Useful for parking the rig after some period of time.
#


from library.PySkyX_ks import *

import time



if (len(sys.argv) == 2):
    hours = sys.argv[1]

else:
    hours = input("How many hours until park? ")

seconds = int((float(hours) * 60 * 60))

print("Waiting " + str(seconds) + " seconds.")

time.sleep(seconds)
softPark()
