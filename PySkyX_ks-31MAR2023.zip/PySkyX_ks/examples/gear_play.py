#!/usr/bin/env python3
#

from library.PySkyX_ks import *


mountConnect()

print(camConnect("Imager"))

